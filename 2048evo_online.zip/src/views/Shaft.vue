<template>
  <div></div>
</template>

<script>
export default {
  name: "shaft",
};
</script>

<style lang="scss" scoped>
</style>